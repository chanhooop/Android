package com.aoslec.androidproject.SaveSharedPreferences;

public class ShareVar {
    public static final String sUrl = "http://172.20.10.4:8080/project/";


}
